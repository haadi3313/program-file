﻿Public Class accountType
    Private mBlalance As Decimal
    Public ReadOnly Property Balance As Decimal
        Get
            Return mBlalance
        End Get
    End Property
    'mehods
    Public Sub Deposit(ByVal amount As Decimal)
        If amount > 0 Then
            mBlalance = mBlalance + amount
        End If
    End Sub
    Public Sub Withdraw(ByVal amount As Decimal)
        If amount <= mBlalance And amount > 0 Then
            mBlalance = mBlalance - amount
        End If
    End Sub
End Class
