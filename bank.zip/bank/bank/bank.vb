﻿Public Class bank
    Dim acc As New accountType
    Private Sub ButtonDeposit_Click(sender As Object, e As EventArgs) Handles ButtonDeposit.Click
        If TextBoxAmount.Text <> String.Empty Then
            acc.Deposit(Convert.ToDecimal(TextBoxAmount.Text))
        End If
        LabelBalance.Text = acc.Balance.ToString("C")
        TextBoxAmount.Clear()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LabelBalance.Text = String.Format("{0:C}", 0)
    End Sub

    Private Sub ButtonWithdraw_Click(sender As Object, e As EventArgs) Handles ButtonWithdraw.Click
        If TextBoxAmount.Text <> String.Empty Then
            acc.Withdraw(Convert.ToDecimal(TextBoxAmount.Text))
        End If
        LabelBalance.Text = acc.Balance.ToString("C")
        TextBoxAmount.Clear()
    End Sub
End Class
